# Income-Tax-Fraud-Detection-AI

![image](https://github.com/user-attachments/assets/e9a832bd-48a7-4e6a-b1b9-0ceaf56d8569)
